// lib/models/notification.dart
class NotificationModel {
  final String id;
  final String message;

  NotificationModel({required this.id, required this.message});
}


