import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart'; // Добавлен импорт
import 'bloc/notification_bloc.dart';
import 'services/firebase_service.dart';
import 'screens/shopping_list_screen.dart';
import 'screens/product_details_screen.dart';
import 'screens/notifications_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    //options: FirebaseOptions(
    //  apiKey: "AIzaSyDvVtO859O2J5L87LiVQBVzMSh438-1zjs",
    //  authDomain: "products-5b50b.firebaseapp.com",
    //  projectId: "products-5b50b",
    //  storageBucket: "products-5b50b.appspot.com",
    //  messagingSenderId: "281187594343",
    //  appId: "1:281187594343:web:78e2461f80e3b7ad27cb3f",
    //),
  ).then((value) => print(value.options.projectId)); // Инициализация Firebase

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<NotificationBloc>(create: (context) => NotificationBloc()),
      ],
      child: MaterialApp(
        title: 'Shopping App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => ShoppingListScreen(),
          '/productDetails': (context) => ProductDetailsScreen(firebaseService: FirebaseService(), product: null),
          '/notifications': (context) => NotificationsScreen(),
        },
      ),
    );
  }
}
