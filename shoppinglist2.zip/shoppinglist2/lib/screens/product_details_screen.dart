// lib/screens/product_details_screen.dart
import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/firebase_service.dart';

class ProductDetailsScreen extends StatelessWidget {
  final FirebaseService firebaseService;
  final Product? product;

  const ProductDetailsScreen({super.key, required this.firebaseService, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(product?.name ?? 'No name'), // если product не null, то используйте его name, иначе используйте 'No name'
            Checkbox(
              value: product?.isPurchased ?? false, // если product не null, то используйте его isPurchased, иначе используйте false
              onChanged: (value) {
                firebaseService.updateProduct(Product(
                  id: product!.id,
                  name: product!.name,
                  isPurchased: value!,
                ));
              },
            ),
          ],
        ),
      ),
    );
  }
}




