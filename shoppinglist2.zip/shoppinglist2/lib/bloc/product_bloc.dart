// bloc/product_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/product.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Product {
  String id;
  String name;
  bool isPurchased;

  // Конструктор для создания объекта Product
  Product({required this.id, required this.name, required this.isPurchased});

  // Метод для конвертации объекта Product в Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'isPurchased': isPurchased,
    };
  }

  // Фабричный метод для создания объекта Product из Map
  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'],
      name: map['name'],
      isPurchased: map['isPurchased'],
    );
  }
}

