// lib/bloc/notification_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/notification.dart';

class NotificationBloc extends Bloc<List<NotificationModel>, List<NotificationModel>> {
  NotificationBloc() : super([]);

  @override
  Stream<List<NotificationModel>> mapEventToState(List<NotificationModel> notifications) async* {
    yield notifications;
  }
}

