package com.example.shoppinglist2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
